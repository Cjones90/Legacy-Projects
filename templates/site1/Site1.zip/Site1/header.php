

<div id='wrapper'>

	<div id='header'>
		<h1>Template #1</h1>
	</div> <!-- header -->

	<div id='nav'>

		<a href='index.php' >Home</a>
		<a href='about.php' >About</a>

	</div>

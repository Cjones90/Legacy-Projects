<!DOCTYPE html>
<html>
<head>
	<title>Practice Page</title>
	<?php include "includes.php" ?>
</head>
<body>
	<?php include "header.php" ?>

	<div id='main_content'>

		<h1 id='main'>Main Content</h1>

	</div> <!-- main_content -->

	<?php include "footer.php" ?>
</body>
</html>
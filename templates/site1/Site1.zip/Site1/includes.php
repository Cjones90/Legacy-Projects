
<link rel='stylesheet' href='style.css?t=<?php echo filemtime('style.css'); ?>'>
<!DOCTYPE html>
<html>
<head>
	<title>Practice Page</title>
	<?php include "includes.php" ?>
</head>
<body>
	<?php include "header.php" ?>

	<div id='main_content'>

		<h1 id='main'>Main Content</h1>

		<img src='images/home-main.jpg' class='home_img'/>
		<h3 class='home_img_overlay'> Your Business Here </h3>

	</div> <!-- main_content -->

	<?php include "footer.php" ?>
</body>
</html>